YO

This mod allows you to use an alternate color palette for Makoto in
Street Fighter III: 3rd Strike.

The file named "palette.txt" contains the RGB string for you to use in
a program called PalMod. Look it up. You can just copy the whole string in the other txt
file and paste it onto any Makoto palette in PalMod (make sure to select
ALL of her colors in the palette in PalMod!). It will replace every
color. If you are stuck or confused at all, please remember that the internet exists.
Use it.

The color palette is based off of one of my original characters named Kemma.
I figured that both Makoto and Kemma already looked somewhat similar, so I
felt that this Kemma palette was very fitting for Makoto. Oh, and I also
included a preview image!

Have fun :)