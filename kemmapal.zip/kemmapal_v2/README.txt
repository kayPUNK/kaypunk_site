YO

This mod allows you to use alternate color palettes for Makoto in
Street Fighter III: 3rd Strike. Made for personal use with the program Fightcade 2.

The file named "palette.txt" contains the RGB string for you to use in
a program called PalMod. Look it up. You can just copy the string for your preferred palette in the other txt
file and paste it onto any Makoto palette in PalMod (make sure to select
ALL of her colors in the chosen palette in PalMod!). It will replace every
color. If you are stuck or confused at all, please remember that the internet exists.
Use it.

The color palette named "Kemma" is based off of one of my original characters of the same name.
I figured that both Makoto and Kemma already looked somewhat similar, so I
felt that this Kemma palette was very fitting for Makoto. Oh, and I also
included two new colors with the v2 update as well as preview images!

Happy fighting! :)